window.PROFILE_CONFIG = {
  minecraftServerIp: "play.furrmc.com",
  discordUserId: "",
  counterApiUrl: ""
};
